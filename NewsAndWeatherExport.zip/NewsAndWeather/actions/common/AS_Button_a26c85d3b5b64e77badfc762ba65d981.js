function AS_Button_a26c85d3b5b64e77badfc762ba65d981(eventobject) {
    var self = this;
    this.openEmail();
}