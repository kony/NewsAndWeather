function AS_RichText_b5bf03a5740d4e9aade23203c3a52ba4(eventobject, linktext, attributes) {
    var self = this;
    this.onLinkClick()
}