function AS_Segment_c15f79c5cf1c42d88f3fb10e1e5c2420(eventobject, sectionNumber, rowNumber) {
    var self = this;
    this.onRowClick();
}