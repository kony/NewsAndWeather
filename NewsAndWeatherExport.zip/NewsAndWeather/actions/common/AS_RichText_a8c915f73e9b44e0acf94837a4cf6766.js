function AS_RichText_a8c915f73e9b44e0acf94837a4cf6766(eventobject, linktext, attributes) {
    var self = this;
    alert("clcickec");
    this.onLinkClick();
}