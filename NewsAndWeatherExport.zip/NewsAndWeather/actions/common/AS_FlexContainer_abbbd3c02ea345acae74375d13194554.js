function AS_FlexContainer_abbbd3c02ea345acae74375d13194554(eventobject) {
    var self = this;
    // if(this.view.rchtextDoc.isVisible === true)
    //   this.onClickDisappear(eventobject);
    // else
    //   this.onClickDisplay(eventobject);
    this.showAccord(eventobject.id);
}