function AS_Button_d35edc11a27e42b28e76d53809c6daf7(eventobject) {
    var self = this;
    this.onClickPlayButton(eventobject.id);
}