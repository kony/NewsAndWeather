function AS_Button_jf7ec43e72814d60aadf22cdef2aa6b6(eventobject) {
    var self = this;
    this.onClickPlayButton(eventobject.id);
}