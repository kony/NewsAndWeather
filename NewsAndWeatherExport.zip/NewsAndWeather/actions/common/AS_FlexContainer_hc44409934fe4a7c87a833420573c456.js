function AS_FlexContainer_hc44409934fe4a7c87a833420573c456(eventobject) {
    // if(this.view.lblCodeSnippet.isVisible === true)
    //   this.onClickDisappear(eventobject);
    // else
    //   this.onClickDisplay(eventobject);
    this.showAccord(eventobject.id);
}