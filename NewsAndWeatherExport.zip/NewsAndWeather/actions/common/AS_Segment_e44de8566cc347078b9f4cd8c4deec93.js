function AS_Segment_e44de8566cc347078b9f4cd8c4deec93(seguiWidget, sectionIndex, rowIndex) {
    var self = this;
    alert("on swipe" + rowIndex);
}