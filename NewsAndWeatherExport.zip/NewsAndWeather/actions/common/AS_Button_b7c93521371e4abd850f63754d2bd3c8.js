function AS_Button_b7c93521371e4abd850f63754d2bd3c8(eventobject) {
    var self = this;
    this.onGetStarted();
}