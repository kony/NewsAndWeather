function AS_Segment_dfc3d2d2383244feb9f2d959e98242bd(eventobject) {
    var self = this;
    alert("onpush");
}